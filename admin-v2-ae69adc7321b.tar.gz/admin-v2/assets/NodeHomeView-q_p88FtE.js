import{a4 as w,a5 as x,o as a,c as n,a6 as r,W as i,i as l,b as o,d as H,a as C,e as m,l as t,w as N,F as f,h as P,a7 as B,j as $,t as u,E as S,z as g,M as V}from"./index-Z__3DxVZ.js";import{P as z}from"./PageHeader-8O0sobM3.js";import{N as I}from"./NodeSyncPanel-Dh7wPhbO.js";import"./index-CP_wIpL2.js";import"./index-_RflWcIi.js";import"./index-rM3Zt8Ss.js";var E=`
    .p-card {
        background: dt('card.background');
        color: dt('card.color');
        box-shadow: dt('card.shadow');
        border-radius: dt('card.border.radius');
        display: flex;
        flex-direction: column;
    }

    .p-card-caption {
        display: flex;
        flex-direction: column;
        gap: dt('card.caption.gap');
    }

    .p-card-body {
        padding: dt('card.body.padding');
        display: flex;
        flex-direction: column;
        gap: dt('card.body.gap');
    }

    .p-card-title {
        font-size: dt('card.title.font.size');
        font-weight: dt('card.title.font.weight');
    }

    .p-card-subtitle {
        color: dt('card.subtitle.color');
    }
`,F={root:"p-card p-component",header:"p-card-header",body:"p-card-body",caption:"p-card-caption",title:"p-card-title",subtitle:"p-card-subtitle",content:"p-card-content",footer:"p-card-footer"},T=w.extend({name:"card",style:E,classes:F}),_={name:"BaseCard",extends:x,style:T,provide:function(){return{$pcCard:this,$parentInstance:this}}},k={name:"Card",extends:_,inheritAttrs:!1};function j(e,s,b,d,y,c){return a(),n("div",r({class:e.cx("root")},e.ptmi("root")),[e.$slots.header?(a(),n("div",r({key:0,class:e.cx("header")},e.ptm("header")),[i(e.$slots,"header")],16)):l("",!0),o("div",r({class:e.cx("body")},e.ptm("body")),[e.$slots.title||e.$slots.subtitle?(a(),n("div",r({key:0,class:e.cx("caption")},e.ptm("caption")),[e.$slots.title?(a(),n("div",r({key:0,class:e.cx("title")},e.ptm("title")),[i(e.$slots,"title")],16)):l("",!0),e.$slots.subtitle?(a(),n("div",r({key:1,class:e.cx("subtitle")},e.ptm("subtitle")),[i(e.$slots,"subtitle")],16)):l("",!0)],16)):l("",!0),o("div",r({class:e.cx("content")},e.ptm("content")),[i(e.$slots,"content")],16),e.$slots.footer?(a(),n("div",r({key:1,class:e.cx("footer")},e.ptm("footer")),[i(e.$slots,"footer")],16)):l("",!0)],16)],16)}k.render=j;const A={class:"flex flex-col gap-4"},D={class:"flex items-start gap-3"},M={class:"min-w-0"},O={class:"m-0 text-lg"},R={class:"font-semibold ltr"},W={class:"text-muted-color mt-2 mb-0"},q={class:"flex flex-wrap gap-2"},Y=H({__name:"NodeHomeView",setup(e){const{t:s}=C(),b=V(),d=B,y=P(()=>{var c;return(c=d.value)!=null&&c.node_name?s("nodeHome.titleNamed",{name:d.value.node_name}):s("nodeHome.title")});return(c,p)=>(a(),n(f,null,[m(z,{title:y.value,subtitle:t(s)("nodeHome.subtitle")},null,8,["title","subtitle"]),m(t(k),null,{content:N(()=>{var h,v;return[o("div",A,[o("div",D,[p[1]||(p[1]=o("i",{class:"pi pi-sitemap text-primary text-2xl mt-1"},null,-1)),o("div",M,[o("p",O,[(h=t(d))!=null&&h.parent_host?(a(),n(f,{key:0},[$(u(t(s)("nodeHome.connectedTo"))+" ",1),o("span",R,u(t(d).parent_host),1)],64)):(a(),n(f,{key:1},[$(u(t(s)("nodeHome.noParent")),1)],64))]),o("p",W,u(t(s)("nodeHome.managedOnParent")),1)])]),o("div",q,[(v=t(d))!=null&&v.parent_dashboard_url?(a(),S(t(g),{key:0,as:"a",href:t(d).parent_dashboard_url,icon:"pi pi-external-link",label:t(s)("nodeHome.openParent")},null,8,["href","label"])):l("",!0),m(t(g),{icon:"pi pi-share-alt",label:t(s)("menu.customProxies"),severity:"secondary",outlined:"",onClick:p[0]||(p[0]=G=>t(b).push({name:"custom-proxy-list"}))},null,8,["label"])])])]}),_:1}),m(I)],64))}});export{Y as default};
